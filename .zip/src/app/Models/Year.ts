export class Year {
    YId: number = 0;
    YearName!: string;
    IsActive!: boolean;
}