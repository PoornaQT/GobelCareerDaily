export class EmployeeType {
    ETId !: number;
    EmployeeTypeName !: string;
    IsActive!: boolean;
}