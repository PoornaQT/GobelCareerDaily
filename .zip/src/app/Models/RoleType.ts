export class RoleType{
    RId !: number;
    RoleTypeName!: string;
    IsActive!: boolean
}