export class OnBoardingStatus {
    OBId !: number;
    OnBoardingStatusName!: string;
    IsActive!: boolean;
}