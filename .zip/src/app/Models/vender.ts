export class Vender {
    VId!: number;
    VenderName!: string;
    IsActive !: boolean;
}