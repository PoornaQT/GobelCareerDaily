
export  class Month{
    MId: number = 0;
    MonthName!: string;
    IsActive!: boolean;
}