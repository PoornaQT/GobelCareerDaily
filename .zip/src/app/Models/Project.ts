export class Project {
    PId: number = 0;
    ProjectName!: string;
    IsActive!: boolean;
}