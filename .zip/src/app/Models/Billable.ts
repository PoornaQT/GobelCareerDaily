export class Billable {
    BId !: number;
    BillableName!: string;
    IsActive!: boolean
}