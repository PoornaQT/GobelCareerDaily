

export class FiscialYear {
    FId: number = 0;
    FiscialYearName!: string;
    IsActive!: boolean
}