

export class Company {
    CId!: number;
    CompanyName!: string;
    Address!: string;
    IsActive!: boolean
}   