
export class Employee {
    FullName !: string;
    Email !: string;
    Contact_number_Primary !: string;
    Contact_number_Alternative !: string;
    Current_Location !: string;
    BirthDate !: Date;
    CompanyId !: number;
    ProjectId !: number;
    CleintId !: number;
    EmployeeTypeId !: number;
    Vender!: number;
    HiringManager !: string;
    StartDate!: Date;
    EndDate!: Date;
    skills !: string;
    BillableId!: number;
    RoleType!: number;
    OnBoardingStatusId!: number;
    Experence !: string;
    IsActive!: boolean;
}