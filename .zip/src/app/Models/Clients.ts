export class Client {
    CId !: number;
    ClientName!: string;
    IsActive!: boolean
}