import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TopnavComponent } from './Components/HomePage/TopNav/topnav/topnav.component';
import { BillingDataComponent } from './Components/Billing/BillingData/billing-data/billing-data.component';
import { MonthlyBudgetComponent } from './Components/Billing/MonthlyBudget/monthly-budget/monthly-budget.component';
import { AddEmployeeComponent } from './Components/Employees/AddEMployee/add-employee/add-employee.component';
import { MonthlyInVoiceComponent } from './Components/Billing/MonthlyInVoice/monthly-in-voice/monthly-in-voice.component';
import { ManageComponent } from './Components/Manage/ManageSidBar/manage/manage.component';

const routes: Routes = [
  {
    path: 'topnav', component: TopnavComponent
  },
  {
    path: 'billingData', component: BillingDataComponent
  },
  {
    path:'monthlyBudget/:BId' ,component:MonthlyBudgetComponent
  },
  {
    path:'addEmployee', component:AddEmployeeComponent
  },
  {
    path:'montlyInvoice', component:MonthlyInVoiceComponent
  },
  {
    path:'manage',component:ManageComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
