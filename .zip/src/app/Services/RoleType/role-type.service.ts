import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API_URLS } from '../../Envirolmant/Env';

@Injectable({
  providedIn: 'root'
})
export class RoleTypeService {

  constructor(private Http:HttpClient) { }

  GetRoleType():any{
    return this.Http.get(
      `${API_URLS.ROLETYPE_API_URL}GetRoleTypes`
    )
  }
}
