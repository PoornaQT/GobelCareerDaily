import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable } from 'rxjs';
import { API_URLS } from '../../Envirolmant/Env';
import { error } from 'console';
import { Billing } from '../../Models/Billing';

@Injectable({
  providedIn: 'root'
})
export class BillingDataService {

  constructor(private Http: HttpClient) { }

  fetchBillingData(): any {
    return this.Http.get(API_URLS.BILLING_API_URL + "GetBillingdata");
  }


  GetPonumberDetails(BId: number): any {
    return this.Http.get(API_URLS.BILLING_API_URL + "GetPONumberDetails_By_BillingId/" + BId);
  }

  deleteBillingData(BId: number) {
    return this.Http.delete(API_URLS.BILLING_API_URL + "Delete_Billing_Data/" + BId);
  }

  GetBillingDataByBillingId(BId: number): any {
    return this.Http.get(API_URLS.BILLING_API_URL + "GetBillingData_ByBillId/" + BId)
  }

  updateBillingData(billingData: Billing): Observable<any> {
    return this.Http.put<any>(API_URLS.BILLING_API_URL + "UpdateBillingData", billingData);
  }

}
