import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API_URLS } from '../../Envirolmant/Env';

@Injectable({
  providedIn: 'root'
})
export class VenderService {

  constructor(private Http: HttpClient) { }


  GetVenders(): any {
    return this.Http.get(`${API_URLS.VENDER_API_URL}GetVenders`);
  }
}
