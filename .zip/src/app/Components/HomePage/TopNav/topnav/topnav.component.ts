import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-topnav',
  templateUrl: './topnav.component.html',
  styleUrl: './topnav.component.css'
})
export class TopnavComponent implements OnInit {


   UseName : String ="PRAVEEN"
  ngOnInit(): void {
  }

  goToBilling(){
    window.location.href === '/billingdata'
  }
  
}
