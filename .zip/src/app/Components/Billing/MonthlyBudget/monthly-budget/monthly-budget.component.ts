import { Component, OnInit } from '@angular/core';
import { Billing, PoNumberDetails } from '../../../../Models/Billing';
import { ActivatedRoute } from '@angular/router';
import { BillingDataService } from '../../../../Services/Billing/billing-data.service';

@Component({
  selector: 'app-monthly-budget',
  templateUrl: './monthly-budget.component.html',
  styleUrl: './monthly-budget.component.css'
})
export class MonthlyBudgetComponent implements OnInit {

  BId: number = 0;
  PonumberDetials: PoNumberDetails = new PoNumberDetails();

  constructor(private activatedRoute: ActivatedRoute,
    private billingService: BillingDataService
  ) { }
  ngOnInit(): void {
    this.activatedRoute.paramMap.subscribe(params => {
      const encodedId = params.get('BId'); 
      if (encodedId) {
        const decodedId =  atob(encodedId); 
        const numericId = Number(decodedId); 
        this.GetPonumberDetails(numericId);
      }
    });
  };


  GetPonumberDetails(BId: number): any {
    this.billingService.GetPonumberDetails(BId).subscribe({
      next: (response: any) => {
        if (response.StatusCode === 200 || response.StatusCode === 201) {
          this.PonumberDetials = response.Data;
        } else {
          console.error("Error retrieving data: ", response.ErrorMessage);
        }
      },
      error: (err: any) => {
        console.error("Error occurred: ", err);
      }
    });
  };


  budgetData = [
    { poNumber: '', month: "", poAmount: null, invoicedAmount: null, invoicedOn: '' },
    // { poNumber: '1000024', month: "Aug' 19", poAmount: 0, invoicedAmount: 0, invoicedOn: '' },
    // { poNumber: '1000024', month: "Sep' 19", poAmount: 0, invoicedAmount: 0, invoicedOn: '' },
    // { poNumber: '1000024', month: "Oct' 19", poAmount: 0, invoicedAmount: 98, invoicedOn: '' },
    // { poNumber: '1000024', month: "Nov' 19", poAmount: 0, invoicedAmount: 0, invoicedOn: '' },
  ];


  get totalPOAmount(): number {
    
    return this.budgetData.reduce((sum, row) => sum + row.poAmount!, 0);

  }

  get totalInvoicedAmount(): number {
    return this.budgetData.reduce((sum, row) => sum + row.invoicedAmount!, 0);
  }
}
